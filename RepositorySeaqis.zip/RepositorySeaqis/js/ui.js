/**
 * ui.js
 * Merender layout (sidebar + topbar) sesuai role pengguna.
 * Menu mengikuti Diagram Sitemap pada lampiran usulan.
 */

const MENU = [
  { label: "Dashboard", href: "dashboard.html", icon: "grid", roles: ["Panitia", "Admin", "Divisi IDE", "Pimpinan"] },
  { label: "Upload Dokumen", href: "upload.html", icon: "upload", roles: ["Panitia"] },
  { label: "Status Dokumen", href: "status-dokumen.html", icon: "clock", roles: ["Panitia"] },
  { label: "Validasi Dokumen", href: "validasi.html", icon: "check-circle", roles: ["Admin"] },
  { label: "Review Dokumen", href: "review.html", icon: "eye", roles: ["Divisi IDE"] },
  { label: "Kelola Repository", href: "kelola-repository.html", icon: "folder", roles: ["Admin"] },
  { label: "Knowledge Repository", href: "repository.html", icon: "book", roles: ["Panitia", "Admin", "Divisi IDE", "Pimpinan"] },
  { label: "Kelola Pengguna", href: "kelola-pengguna.html", icon: "users", roles: ["Admin"] },
  { label: "Laporan KM", href: "laporan.html", icon: "bar-chart", roles: ["Admin", "Pimpinan"] },
];

const ICONS = {
  grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
  upload: '<path d="M12 19V5M5 12l7-7 7 7"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>',
  "check-circle": '<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
  folder: '<path d="M3 6a2 2 0 012-2h4l2 2h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V6z"/>',
  book: '<path d="M4 4h11a3 3 0 013 3v13H7a3 3 0 01-3-3V4z"/><path d="M4 4v13a3 3 0 003 3"/>',
  users: '<circle cx="9" cy="8" r="3"/><path d="M2 20c0-3.3 3-6 7-6s7 2.7 7 6"/><circle cx="17" cy="9" r="2.5"/><path d="M22 20c0-2.5-2-4.5-4.5-5"/>',
  "bar-chart": '<path d="M4 20V10M12 20V4M20 20v-7"/>',
  "log-out": '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
};

function icon(name, size = 18) {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] || ""}</svg>`;
}

function renderLayout(activeHref, session) {
  const items = MENU.filter((m) => m.roles.includes(session.role));
  const nav = items
    .map(
      (m) => `
    <a class="nav-item ${m.href === activeHref ? "active" : ""}" href="${m.href}">
      ${icon(m.icon)}<span>${m.label}</span>
    </a>`
    )
    .join("");

  document.getElementById("sidebar").innerHTML = `
    <div class="brand">
      <div class="brand-mark">KM</div>
      <div class="brand-text">
        <strong>SEAQIS</strong>
        <span>Divisi IDE</span>
      </div>
    </div>
    <nav class="nav">${nav}</nav>
    <button class="nav-item logout" id="btn-logout">${icon("log-out")}<span>Keluar</span></button>
  `;

  document.getElementById("topbar").innerHTML = `
    <div class="topbar-title" id="page-title"></div>
    <div class="topbar-user">
      <span class="role-badge">${session.role}</span>
      <div class="user-chip">
        <div class="avatar">${session.nama.charAt(0)}</div>
        <span>${session.nama}</span>
      </div>
    </div>
  `;

  document.getElementById("btn-logout").addEventListener("click", () => {
    logout();
    window.location.href = "../index.html";
  });
}

function setPageTitle(title) {
  const el = document.getElementById("page-title");
  if (el) el.textContent = title;
}

function statusBadgeClass(status) {
  switch (status) {
    case STATUS.DIPUBLIKASIKAN:
      return "badge badge-green";
    case STATUS.MENUNGGU_REVIEW:
    case STATUS.MENUNGGU_VALIDASI:
      return "badge badge-amber";
    case STATUS.REVISI:
      return "badge badge-red";
    default:
      return "badge";
  }
}

function toast(message) {
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = message;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add("show"));
  setTimeout(() => {
    el.classList.remove("show");
    setTimeout(() => el.remove(), 300);
  }, 2600);
}
