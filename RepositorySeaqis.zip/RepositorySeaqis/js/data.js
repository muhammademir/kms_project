/**
 * data.js
 * Mock database menggunakan localStorage.
 * Struktur tabel mengikuti perancangan ERD pada lampiran usulan skripsi:
 * - tb_users      : data pengguna & role
 * - tb_kategori   : kategori knowledge pada repository
 * - tb_dokumen    : dokumen knowledge beserta metadata & status alur kerja
 * - tb_log        : log aktivitas (untuk Laporan KM)
 */

const DB_KEYS = {
  USERS: "kms_tb_users",
  KATEGORI: "kms_tb_kategori",
  DOKUMEN: "kms_tb_dokumen",
  LOG: "kms_tb_log",
  SESSION: "kms_session",
};

const STATUS = {
  MENUNGGU_VALIDASI: "Menunggu Validasi",
  REVISI: "Revisi",
  MENUNGGU_REVIEW: "Menunggu Review",
  DIPUBLIKASIKAN: "Dipublikasikan",
};

function seedIfEmpty() {
  if (!localStorage.getItem(DB_KEYS.USERS)) {
    const users = [
      { id: 1, nama: "Sari Panitia", username: "panitia", password: "panitia123", role: "Panitia" },
      { id: 2, nama: "Rudi Admin", username: "admin", password: "admin123", role: "Admin" },
      { id: 3, nama: "Dewi IDE", username: "divisiide", password: "ide123", role: "Divisi IDE" },
      { id: 4, nama: "Bapak Kepala Pusat", username: "pimpinan", password: "pimpinan123", role: "Pimpinan" },
    ];
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
  }

  if (!localStorage.getItem(DB_KEYS.KATEGORI)) {
    const kategori = [
      { id: 1, nama: "Laporan Kegiatan" },
      { id: 2, nama: "Laporan Evaluasi" },
      { id: 3, nama: "SOP" },
      { id: 4, nama: "Notulen Rapat" },
      { id: 5, nama: "Dokumentasi Kegiatan" },
    ];
    localStorage.setItem(DB_KEYS.KATEGORI, JSON.stringify(kategori));
  }

  if (!localStorage.getItem(DB_KEYS.DOKUMEN)) {
    const now = new Date().toISOString().slice(0, 10);
    const dokumen = [
      {
        id: 1,
        judul: "Laporan Kegiatan Training Guru IPA 2025",
        deskripsi: "Laporan pelaksanaan training guru IPA batch 1 tahun 2025.",
        kategoriId: 1,
        tags: ["training", "guru ipa", "2025"],
        fileName: "laporan-training-ipa-2025.pdf",
        uploaderId: 1,
        status: STATUS.DIPUBLIKASIKAN,
        catatanRevisi: "",
        tanggalUpload: now,
        tanggalUpdate: now,
      },
      {
        id: 2,
        judul: "SOP Pengajuan Research Grant",
        deskripsi: "Standar operasional prosedur pengajuan research grant SEAQIS.",
        kategoriId: 3,
        tags: ["sop", "research grant"],
        fileName: "sop-research-grant.pdf",
        uploaderId: 1,
        status: STATUS.DIPUBLIKASIKAN,
        catatanRevisi: "",
        tanggalUpload: now,
        tanggalUpdate: now,
      },
      {
        id: 3,
        judul: "Notulen Rapat Koordinasi Workshop Sains",
        deskripsi: "Notulen rapat koordinasi persiapan workshop sains regional.",
        kategoriId: 4,
        tags: ["notulen", "workshop"],
        fileName: "notulen-workshop-sains.pdf",
        uploaderId: 1,
        status: STATUS.MENUNGGU_VALIDASI,
        catatanRevisi: "",
        tanggalUpload: now,
        tanggalUpdate: now,
      },
      {
        id: 4,
        judul: "Laporan Evaluasi Seminar Internasional",
        deskripsi: "Evaluasi pelaksanaan seminar internasional SEAQIS tahun berjalan.",
        kategoriId: 2,
        tags: ["evaluasi", "seminar"],
        fileName: "evaluasi-seminar-internasional.pdf",
        uploaderId: 1,
        status: STATUS.MENUNGGU_REVIEW,
        catatanRevisi: "",
        tanggalUpload: now,
        tanggalUpdate: now,
      },
      {
        id: 5,
        judul: "Dokumentasi Kegiatan Conference Sains 2024",
        deskripsi: "Draft dokumentasi kegiatan yang perlu diperbaiki.",
        kategoriId: 5,
        tags: ["dokumentasi", "conference"],
        fileName: "dokumentasi-conference-2024.pdf",
        uploaderId: 1,
        status: STATUS.REVISI,
        catatanRevisi: "Mohon lengkapi lampiran daftar hadir peserta.",
        tanggalUpload: now,
        tanggalUpdate: now,
      },
    ];
    localStorage.setItem(DB_KEYS.DOKUMEN, JSON.stringify(dokumen));
  }

  if (!localStorage.getItem(DB_KEYS.LOG)) {
    localStorage.setItem(DB_KEYS.LOG, JSON.stringify([]));
  }
}

function getTable(key) {
  return JSON.parse(localStorage.getItem(key) || "[]");
}
function setTable(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}
function nextId(rows) {
  return rows.length ? Math.max(...rows.map((r) => r.id)) + 1 : 1;
}
function addLog(aksi, detail) {
  const log = getTable(DB_KEYS.LOG);
  log.push({
    id: nextId(log),
    aksi,
    detail,
    tanggal: new Date().toISOString(),
    userId: getSession()?.id || null,
  });
  setTable(DB_KEYS.LOG, log);
}

// ---- Session ----
function login(username, password) {
  const users = getTable(DB_KEYS.USERS);
  const user = users.find((u) => u.username === username && u.password === password);
  if (user) {
    localStorage.setItem(DB_KEYS.SESSION, JSON.stringify(user));
    return user;
  }
  return null;
}
function logout() {
  localStorage.removeItem(DB_KEYS.SESSION);
}
function getSession() {
  const raw = localStorage.getItem(DB_KEYS.SESSION);
  return raw ? JSON.parse(raw) : null;
}
function requireLogin(allowedRoles) {
  const session = getSession();
  if (!session) {
    window.location.href = pathToRoot() + "index.html";
    return null;
  }
  if (allowedRoles && !allowedRoles.includes(session.role)) {
    alert("Anda tidak memiliki akses ke halaman ini.");
    window.location.href = pathToRoot() + "pages/dashboard.html";
    return null;
  }
  return session;
}
function pathToRoot() {
  return window.location.pathname.includes("/pages/") ? "../" : "";
}

seedIfEmpty();
