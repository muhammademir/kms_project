# Prototype KMS SEAQIS — Divisi IDE

Prototype front-end (HTML, CSS, JavaScript murni — tanpa framework/backend) untuk
Knowledge Management System (KMS) Divisi ICT, Data, dan Evaluation (IDE) SEAQIS,
berdasarkan Lampiran Usulan skripsi (use case, activity diagram, class diagram,
ERD repository, sitemap, dan mockup interface).

Data disimpan di `localStorage` browser sebagai simulasi database (mock DB),
sehingga prototype bisa langsung dijalankan tanpa server/backend.

## Cara menjalankan di VS Code

1. Buka folder `kms-seaqis` di VS Code.
2. Install extension **Live Server** (opsional tapi disarankan).
3. Klik kanan `index.html` → **Open with Live Server**.
   (Atau cukup buka `index.html` langsung di browser — semua sudah client-side.)

## Struktur folder

```
kms-seaqis/
├── index.html                  # Halaman login
├── css/
│   └── style.css               # Design token & seluruh styling
├── js/
│   ├── data.js                 # Mock database (tb_users, tb_kategori, tb_dokumen, tb_log) + auth/session
│   └── ui.js                   # Render sidebar/topbar per role, badge status, toast
├── pages/
│   ├── dashboard.html          # Ringkasan sesuai role
│   ├── upload.html             # UC-01 Upload Dokumen (Panitia)
│   ├── status-dokumen.html     # UC-02 Revisi Dokumen (Panitia)
│   ├── validasi.html           # UC-03 Validasi Dokumen (Admin)
│   ├── review.html             # UC-04 Review Dokumen (Divisi IDE)
│   ├── kelola-repository.html  # UC-05 Kelola Repository: kategori & tagging (Admin)
│   ├── repository.html         # UC-06 Pencarian Knowledge: Tag/Full Text/Rule-Based Search
│   ├── document-detail.html    # Detail dokumen pada repository
│   ├── kelola-pengguna.html    # UC-07 Kelola Pengguna (Admin)
│   └── laporan.html            # UC-08 Laporan KM (Admin & Pimpinan)
└── README.md
```

## Alur status dokumen (mengikuti activity diagram)

```
Upload (Panitia)
   -> Menunggu Validasi
        -> [lengkap] Admin -> Menunggu Review
        -> [tidak lengkap] Admin -> Revisi -> kembali ke Panitia
   Menunggu Review
        -> [disetujui] Divisi IDE -> Dipublikasikan (masuk Knowledge Repository)
        -> [ditolak] Divisi IDE -> Revisi -> kembali ke Panitia
```

## Akun demo

| Role        | Username    | Password     |
|-------------|-------------|--------------|
| Panitia     | panitia     | panitia123   |
| Admin       | admin       | admin123     |
| Divisi IDE  | divisiide   | ide123       |
| Pimpinan    | pimpinan    | pimpinan123  |

## Catatan pengembangan lanjutan

Prototype ini murni front-end. Untuk implementasi produksi, `js/data.js` dapat
diganti dengan pemanggilan REST API ke backend + database MySQL (tabel `tb_users`,
`tb_dokumen`, `tb_kategori`, dst. sesuai ERD pada skripsi), dan upload file diarahkan
ke penyimpanan berkas sungguhan (mis. server storage atau object storage).
